import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import crypto from "node:crypto";
import { mkdirSync, writeFileSync } from "node:fs";
import { DatabaseSync } from "node:sqlite";
import { dirname, join } from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

dotenv.config({ path: new URL("./.env", import.meta.url) });

const app = express();
const PORT = process.env.PORT || 5001;
const databasePath = join(dirname(fileURLToPath(import.meta.url)), "data", "medicare.db");
const jsonDataPath = join(dirname(fileURLToPath(import.meta.url)), "data.json");

mkdirSync(dirname(databasePath), { recursive: true });
const database = new DatabaseSync(databasePath);
database.exec(`
  CREATE TABLE IF NOT EXISTS appointments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    doctor TEXT NOT NULL,
    date TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('patient', 'doctor', 'admin')),
    status TEXT NOT NULL DEFAULT 'approved'
      CHECK (status IN ('pending', 'approved', 'rejected')),
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS chat_bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER NOT NULL REFERENCES users(id),
    doctor_id INTEGER NOT NULL REFERENCES users(id),
    plan INTEGER NOT NULL CHECK (plan IN (200, 500)),
    status TEXT NOT NULL DEFAULT 'booked',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS chat_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    booking_id INTEGER NOT NULL REFERENCES chat_bookings(id),
    sender_id INTEGER NOT NULL REFERENCES users(id),
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS doctor_profiles (
    user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    specialty TEXT NOT NULL DEFAULT 'General Physician',
    experience_years INTEGER NOT NULL DEFAULT 1,
    qualification TEXT NOT NULL DEFAULT 'MBBS',
    consultation_fee INTEGER NOT NULL DEFAULT 200,
    bio TEXT NOT NULL DEFAULT 'Experienced healthcare professional.',
    available INTEGER NOT NULL DEFAULT 1
  );
  CREATE TABLE IF NOT EXISTS login_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT NOT NULL,
    role TEXT,
    success INTEGER NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);
for (const column of ["patient_last_read_at", "doctor_last_read_at"]) {
  try {
    database.exec(`ALTER TABLE chat_bookings ADD COLUMN ${column} TEXT`);
  } catch (error) {
    if (!String(error.message).includes("duplicate column name")) throw error;
  }
  for (const column of ["attachment_name", "attachment_data"]) {
    try {
      database.exec(`ALTER TABLE chat_messages ADD COLUMN ${column} TEXT`);
    } catch (error) {
      if (!String(error.message).includes("duplicate column name")) throw error;
    }
  }
}

function exportJsonData() {
  const data = {
    generated_at: new Date().toISOString(),
    users: database
      .prepare("SELECT id, name, email, role, status, created_at FROM users ORDER BY id")
      .all(),
    doctor_profiles: database
      .prepare("SELECT * FROM doctor_profiles ORDER BY user_id")
      .all(),
    sessions: database
      .prepare("SELECT user_id, created_at FROM sessions ORDER BY created_at DESC")
      .all(),
    appointments: database
      .prepare("SELECT * FROM appointments ORDER BY date, id")
      .all(),
    chat_bookings: database
      .prepare("SELECT * FROM chat_bookings ORDER BY id")
      .all(),
    chat_messages: database
      .prepare("SELECT * FROM chat_messages ORDER BY id")
      .all(),
    login_logs: database
      .prepare("SELECT * FROM login_logs ORDER BY id DESC")
      .all(),
  };

  writeFileSync(jsonDataPath, `${JSON.stringify(data, null, 2)}\n`);
}

const adminEmail = process.env.ADMIN_EMAIL || "admin@gmail.com";
const adminPassword = process.env.ADMIN_PASSWORD || "admin123@";
const existingAdmin = database.prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1").get();
if (existingAdmin) {
  database
    .prepare("UPDATE users SET name = ?, email = ?, password_hash = ?, status = 'approved' WHERE id = ?")
    .run("admin", adminEmail, bcrypt.hashSync(adminPassword, 10), existingAdmin.id);
} else {
  database
    .prepare("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'admin')")
    .run("admin", adminEmail, bcrypt.hashSync(adminPassword, 10));
  console.log(`Default admin created: ${adminEmail}`);
}
const sampleDoctors = [
  ["Dr. Anita Sharma", "anita@medicare.local", "Cardiologist", 12, "MBBS, MD Cardiology", 500, "Specializes in preventive cardiology, hypertension, and heart health."],
  ["Dr. Rahul Mehta", "rahul@medicare.local", "Dermatologist", 9, "MBBS, MD Dermatology", 200, "Treats skin, hair, and nail conditions with patient-focused care."],
  ["Dr. Priya Nair", "priya@medicare.local", "Pediatrician", 10, "MBBS, DCH", 500, "Provides compassionate primary care for infants, children, and teenagers."],
  ["Dr. Arjun Rao", "arjun@medicare.local", "Orthopedic", 14, "MBBS, MS Orthopedics", 500, "Focuses on joint health, sports injuries, and rehabilitation plans."],
];
for (const [name, email, specialty, experience, qualification, fee, bio] of sampleDoctors) {
  database
    .prepare(`
      INSERT OR IGNORE INTO users (name, email, password_hash, role, status)
      VALUES (?, ?, ?, 'doctor', 'approved')
    `)
    .run(name, email, bcrypt.hashSync("doctor123@", 10));
  const doctor = database.prepare("SELECT id FROM users WHERE email = ?").get(email);
  database
    .prepare(`
      INSERT INTO doctor_profiles
        (user_id, specialty, experience_years, qualification, consultation_fee, bio)
      VALUES (?, ?, ?, ?, ?, ?)
      ON CONFLICT(user_id) DO UPDATE SET
        specialty = excluded.specialty,
        experience_years = excluded.experience_years,
        qualification = excluded.qualification,
        consultation_fee = excluded.consultation_fee,
        bio = excluded.bio
    `)
    .run(doctor.id, specialty, experience, qualification, fee, bio);
}
exportJsonData();

app.use(cors());
app.use(express.json());

function publicUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    status: user.status,
  };
}

function auth(requiredRoles = []) {
  return (req, res, next) => {
    const token = req.headers.authorization?.replace("Bearer ", "");
    const user = token
      ? database
          .prepare("SELECT users.* FROM sessions JOIN users ON users.id = sessions.user_id WHERE token = ?")
          .get(token)
      : null;

    if (!user) return res.status(401).json({ error: "Please log in." });
    if (requiredRoles.length && !requiredRoles.includes(user.role)) {
      return res.status(403).json({ error: "You do not have permission for this action." });
    }

    req.user = user;
    next();
  };
}

app.get("/", (req, res) => {
  res.send("MediCare Backend is running!");
});

app.post("/api/auth/register", (req, res) => {
  const { name, email, password, role = "patient" } = req.body;
  if (
    typeof name !== "string" ||
    !name.trim() ||
    typeof email !== "string" ||
    !email.trim() ||
    typeof password !== "string" ||
    password.length < 6 ||
    !["patient", "doctor"].includes(role)
  ) {
    return res.status(400).json({
      error: "Name, valid email, and a password of at least 6 characters are required.",
    });
  }

  try {
    const status = role === "doctor" ? "pending" : "approved";
    const result = database
      .prepare(
        "INSERT INTO users (name, email, password_hash, role, status) VALUES (?, ?, ?, ?, ?)"
      )
      .run(name.trim(), email.trim().toLowerCase(), bcrypt.hashSync(password, 10), role, status);
    if (role === "doctor") {
      database
        .prepare(`
          INSERT INTO doctor_profiles
            (user_id, specialty, experience_years, qualification, consultation_fee, bio)
          VALUES (?, ?, ?, ?, ?, ?)
        `)
        .run(
          result.lastInsertRowid,
          String(req.body.specialty || "General Physician").trim(),
          Math.max(0, Number(req.body.experienceYears) || 1),
          String(req.body.qualification || "MBBS").trim(),
          [200, 500].includes(Number(req.body.consultationFee))
            ? Number(req.body.consultationFee)
            : 200,
          String(req.body.bio || "Experienced healthcare professional.").trim()
        );
    }
    res.status(201).json({
      message:
        role === "doctor"
          ? "Registration submitted. An admin must approve your account."
          : "Registration successful. You can now log in.",
      userId: Number(result.lastInsertRowid),
    });
    exportJsonData();
  } catch (error) {
    if (
      error.code === "SQLITE_CONSTRAINT_UNIQUE" ||
      String(error.message).includes("UNIQUE constraint failed: users.email")
    ) {
      return res.status(409).json({ error: "An account with this email already exists." });
    }
    throw error;
  }
});

app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const user = database
    .prepare("SELECT * FROM users WHERE email = ?")
    .get(String(email || "").trim().toLowerCase());

  if (!user || !bcrypt.compareSync(String(password || ""), user.password_hash)) {
    database
      .prepare("INSERT INTO login_logs (email, success) VALUES (?, 0)")
      .run(String(email || "").trim().toLowerCase());
    exportJsonData();
    return res.status(401).json({ error: "Invalid email or password." });
  }
  if (user.status === "pending") {
    database
      .prepare("INSERT INTO login_logs (email, role, success) VALUES (?, ?, 0)")
      .run(user.email, user.role);
    exportJsonData();
    return res.status(403).json({ error: "Your doctor account is waiting for admin approval." });
  }
  if (user.status === "rejected") {
    database
      .prepare("INSERT INTO login_logs (email, role, success) VALUES (?, ?, 0)")
      .run(user.email, user.role);
    exportJsonData();
    return res.status(403).json({ error: "Your account was rejected by the admin." });
  }

  const token = crypto.randomBytes(32).toString("hex");
  database.prepare("INSERT INTO sessions (token, user_id) VALUES (?, ?)").run(token, user.id);
  database
    .prepare("INSERT INTO login_logs (email, role, success) VALUES (?, ?, 1)")
    .run(user.email, user.role);
  exportJsonData();
  res.json({ token, user: publicUser(user) });
});

app.post("/api/auth/logout", auth(), (req, res) => {
  const token = req.headers.authorization?.replace("Bearer ", "");
  database.prepare("DELETE FROM sessions WHERE token = ?").run(token);
  exportJsonData();
  res.status(204).end();
});

app.get("/api/auth/me", auth(), (req, res) => {
  res.json(publicUser(req.user));
});

app.get("/api/admin/doctors", auth(["admin"]), (req, res) => {
  res.json(
    database
      .prepare(
        "SELECT id, name, email, status, created_at FROM users WHERE role = 'doctor' ORDER BY created_at DESC"
      )
      .all()
  );
});

app.patch("/api/admin/doctors/:id", auth(["admin"]), (req, res) => {
  const status = req.body.status;
  if (!["approved", "rejected"].includes(status)) {
    return res.status(400).json({ error: "Status must be approved or rejected." });
  }
  const result = database
    .prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'doctor'")
    .run(status, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Doctor not found." });
  exportJsonData();
  res.json({ message: `Doctor ${status}.` });
});

app.get("/api/doctors", (req, res) => {
  res.json(
    database
      .prepare(`
        SELECT users.id, users.name, users.email, profiles.specialty,
          profiles.experience_years, profiles.qualification, profiles.consultation_fee,
          profiles.bio, profiles.available
        FROM users
        LEFT JOIN doctor_profiles profiles ON profiles.user_id = users.id
        WHERE users.role = 'doctor' AND users.status = 'approved'
      `)
      .all()
  );
});

app.get("/api/doctors/:id", (req, res) => {
  const doctor = database
    .prepare(`
      SELECT users.id, users.name, users.email, profiles.specialty,
        profiles.experience_years, profiles.qualification, profiles.consultation_fee,
        profiles.bio, profiles.available
      FROM users
      LEFT JOIN doctor_profiles profiles ON profiles.user_id = users.id
      WHERE users.id = ? AND users.role = 'doctor' AND users.status = 'approved'
    `)
    .get(Number(req.params.id));
  if (!doctor) return res.status(404).json({ error: "Doctor not found." });
  res.json(doctor);
});

app.patch("/api/doctors/me/availability", auth(["doctor"]), (req, res) => {
  const available = req.body.available ? 1 : 0;
  database
    .prepare(`
      INSERT INTO doctor_profiles (user_id, available) VALUES (?, ?)
      ON CONFLICT(user_id) DO UPDATE SET available = excluded.available
    `)
    .run(req.user.id, available);
  exportJsonData();
  res.json({ available: Boolean(available) });
});

app.get("/api/chat/bookings", auth(), (req, res) => {
  const bookings = database
    .prepare(`
      SELECT chat_bookings.id, chat_bookings.plan, chat_bookings.status,
        chat_bookings.created_at,
        doctors.name AS doctor, patients.name AS patient,
        (SELECT COUNT(*) FROM chat_messages unread
          WHERE unread.booking_id = chat_bookings.id
          AND unread.sender_id != ?
          AND unread.created_at > COALESCE(
            CASE WHEN chat_bookings.patient_id = ? THEN chat_bookings.patient_last_read_at
                 ELSE chat_bookings.doctor_last_read_at END,
            '1970-01-01'
          )) AS unread_count
      FROM chat_bookings
      JOIN users doctors ON doctors.id = chat_bookings.doctor_id
      JOIN users patients ON patients.id = chat_bookings.patient_id
      WHERE chat_bookings.patient_id = ? OR chat_bookings.doctor_id = ?
      ORDER BY chat_bookings.id DESC
    `)
    .all(req.user.id, req.user.id, req.user.id, req.user.id);
  res.json(bookings);
});

app.patch("/api/chat/bookings/:id/status", auth(["patient", "doctor"]), (req, res) => {
  const status = req.body.status;
  if (!["active", "completed", "cancelled"].includes(status)) {
    return res.status(400).json({ error: "Invalid chat status." });
  }
  const result = database
    .prepare("UPDATE chat_bookings SET status = ? WHERE id = ? AND (patient_id = ? OR doctor_id = ?)")
    .run(status, Number(req.params.id), req.user.id, req.user.id);
  if (!result.changes) return res.status(404).json({ error: "Chat booking not found." });
  exportJsonData();
  res.json({ status });
});

app.post("/api/chat/bookings", auth(["patient"]), (req, res) => {
  const doctorId = Number(req.body.doctorId);
  const plan = Number(req.body.plan);
  if (![200, 500].includes(plan)) {
    return res.status(400).json({ error: "Choose the ₹200 or ₹500 chat plan." });
  }
  const doctor = database
    .prepare(`
      SELECT users.id
      FROM users
      JOIN doctor_profiles ON doctor_profiles.user_id = users.id
      WHERE users.id = ? AND users.role = 'doctor'
        AND users.status = 'approved' AND doctor_profiles.available = 1
    `)
    .get(doctorId);
  if (!doctor) return res.status(404).json({ error: "Approved doctor not found." });

  const result = database
    .prepare("INSERT INTO chat_bookings (patient_id, doctor_id, plan) VALUES (?, ?, ?)")
    .run(req.user.id, doctorId, plan);
  exportJsonData();
  res.status(201).json({
    id: Number(result.lastInsertRowid),
    plan,
    message: "Chat booking recorded. Payment gateway can be connected later.",
  });
});

app.get("/api/chat/bookings/:id/messages", auth(), (req, res) => {
  const booking = database
    .prepare("SELECT * FROM chat_bookings WHERE id = ? AND (patient_id = ? OR doctor_id = ?)")
    .get(Number(req.params.id), req.user.id, req.user.id);
  if (!booking) return res.status(404).json({ error: "Chat booking not found." });
  const readColumn = booking.patient_id === req.user.id ? "patient_last_read_at" : "doctor_last_read_at";
  database
    .prepare(`UPDATE chat_bookings SET ${readColumn} = CURRENT_TIMESTAMP WHERE id = ?`)
    .run(booking.id);
  res.json(
    database
      .prepare("SELECT id, sender_id, message, attachment_name, attachment_data, created_at FROM chat_messages WHERE booking_id = ? ORDER BY id")
      .all(booking.id)
  );
});

app.post("/api/chat/bookings/:id/messages", auth(["patient", "doctor"]), (req, res) => {
  const message = String(req.body.message || "").trim();
  const attachment = req.body.attachment;
  const booking = database
    .prepare("SELECT * FROM chat_bookings WHERE id = ? AND (patient_id = ? OR doctor_id = ?)")
    .get(Number(req.params.id), req.user.id, req.user.id);
  if (!booking) return res.status(404).json({ error: "Chat booking not found." });
  if (!message && !attachment?.data) return res.status(400).json({ error: "Message cannot be empty." });
  if (attachment?.data && String(attachment.data).length > 2_500_000) {
    return res.status(413).json({ error: "Attachments must be smaller than 2 MB." });
  }
  const result = database
    .prepare("INSERT INTO chat_messages (booking_id, sender_id, message, attachment_name, attachment_data) VALUES (?, ?, ?, ?, ?)")
    .run(booking.id, req.user.id, message, attachment?.name || null, attachment?.data || null);
  exportJsonData();
  res.status(201).json({
    id: Number(result.lastInsertRowid),
    sender_id: req.user.id,
    message,
    attachment_name: attachment?.name || null,
    created_at: new Date().toISOString(),
  });
});

app.get("/api/appointments", (req, res) => {
  res.json(
    database
      .prepare("SELECT id, name, doctor, date FROM appointments ORDER BY date, id")
      .all()
  );
});

app.get("/api/data", (req, res) => {
  exportJsonData();
  res.sendFile(jsonDataPath);
});

app.post("/api/appointments", (req, res) => {
  const { name, doctor, date } = req.body;
  if (
    typeof name !== "string" ||
    !name.trim() ||
    typeof doctor !== "string" ||
    !doctor.trim() ||
    typeof date !== "string" ||
    !date.trim()
  ) {
    return res.status(400).json({ error: "Name, doctor, and date are required." });
  }
  const result = database
    .prepare("INSERT INTO appointments (name, doctor, date) VALUES (?, ?, ?)")
    .run(name.trim(), doctor.trim(), date);
  exportJsonData();
  res.status(201).json({
    id: Number(result.lastInsertRowid),
    name: name.trim(),
    doctor: doctor.trim(),
    date,
  });
});

app.delete("/api/appointments/:id", (req, res) => {
  const result = database.prepare("DELETE FROM appointments WHERE id = ?").run(Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Appointment not found." });
  exportJsonData();
  res.status(204).end();
});

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body.message || "").trim();
    if (!message) return res.status(400).json({ error: "Please enter a message." });
    if (!process.env.OPENROUTER_API_KEY) {
      return res.status(503).json({ error: "AI service is not configured." });
    }
    const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "openrouter/free",
        messages: [
          {
            role: "system",
            content:
              "You are MediCare AI. Give general health information, never diagnose or prescribe, and advise emergency care for serious symptoms.",
          },
          { role: "user", content: message },
        ],
      }),
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: "AI service request failed." });
    res.json({ reply: data.choices?.[0]?.message?.content || "No response received." });
  } catch (error) {
    console.error("Chatbot error:", error);
    res.status(500).json({ error: "Unable to get a response. Please try again." });
  }
});

app.listen(PORT, () => {
  console.log(`MediCare backend running at http://localhost:${PORT}`);
});
