import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export default function Navbar() {
  const [user, setUser] = useState(() =>
    JSON.parse(localStorage.getItem('medicare_user') || 'null')
  )

  useEffect(() => {
    function syncUser() {
      setUser(JSON.parse(localStorage.getItem('medicare_user') || 'null'))
    }

    window.addEventListener('medicare-auth-changed', syncUser)
    return () => window.removeEventListener('medicare-auth-changed', syncUser)
  }, [])

  function logout() {
    localStorage.removeItem('medicare_token')
    localStorage.removeItem('medicare_user')
    setUser(null)
    window.dispatchEvent(new Event('medicare-auth-changed'))
    window.location.href = '/auth'
  }

  return (
    <nav className="navbar">
      <h2>MediCare</h2>

      <div className="links">
        <Link to="/">Home</Link>
        {!user && <Link to="/doctors">Doctors</Link>}
        {user?.role === 'patient' && (
          <>
            <Link to="/doctors">Doctors</Link>
            <Link to="/appointment">Book Appointment</Link>
            <Link to="/my-appointments">My Appointments</Link>
            <Link to="/chat">Doctor Chat</Link>
          </>
        )}
        {user?.role === 'doctor' && (
          <>
            <Link to="/doctor-dashboard">Doctor Workspace</Link>
            <Link to="/chat">Patient Chats</Link>
          </>
        )}
        {user?.role === 'admin' && <Link to="/admin">Admin Dashboard</Link>}
        {user ? (
          <button className="nav-button" onClick={logout}>Logout</button>
        ) : (
          <Link to="/auth">Login</Link>
        )}
      </div>
    </nav>
  )
}