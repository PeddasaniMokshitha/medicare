import { Navigate } from 'react-router-dom'

export default function ProtectedRoute({ children, roles }) {
  const token = localStorage.getItem('medicare_token')
  const user = JSON.parse(localStorage.getItem('medicare_user') || 'null')

  if (!token || !user) return <Navigate to="/auth" replace />
  if (roles && !roles.includes(user.role)) return <Navigate to="/" replace />

  return children
}
