import { useCallback, useEffect, useMemo, useState } from 'react'

export default function DoctorChat() {
  const token = localStorage.getItem('medicare_token')
  const user = JSON.parse(localStorage.getItem('medicare_user') || 'null')
  const userId = user?.id
  const headers = useMemo(() => ({ Authorization: `Bearer ${token}` }), [token])
  const [doctors, setDoctors] = useState([])
  const [bookings, setBookings] = useState([])
  const [selectedDoctor, setSelectedDoctor] = useState('')
  const [selectedBooking, setSelectedBooking] = useState(null)
  const [messages, setMessages] = useState([])
  const [message, setMessage] = useState('')
  const [attachment, setAttachment] = useState(null)
  const [available, setAvailable] = useState(false)
  const [error, setError] = useState('')
  const [loadingDoctors, setLoadingDoctors] = useState(false)

  const loadBookings = useCallback(async () => {
    const response = await fetch('http://localhost:5001/api/chat/bookings', { headers })
    if (response.ok) setBookings(await response.json())
  }, [headers])

  const loadDoctors = useCallback(async () => {
    setLoadingDoctors(true)
    const response = await fetch('http://localhost:5001/api/doctors', { headers })
    if (response.ok) {
      setDoctors(await response.json())
    } else {
      setError('Unable to load approved doctors. Please log in again.')
    }
    setLoadingDoctors(false)
  }, [headers])

  useEffect(() => {
    if (!token) return undefined
    const initialLoad = window.setTimeout(() => {
      loadBookings()
      if (user?.role === 'patient') {
        loadDoctors()
      } else if (user?.role === 'doctor') {
        fetch(`http://localhost:5001/api/doctors/${userId}`)
          .then((response) => response.ok ? response.json() : null)
          .then((doctor) => {
            if (doctor) setAvailable(Boolean(doctor.available))
          })
          .catch((loadError) => console.error(loadError))
      }
    }, 0)
    const interval = window.setInterval(loadBookings, 4000)
    return () => {
      window.clearTimeout(initialLoad)
      window.clearInterval(interval)
    }
  }, [token, user?.role, userId, loadBookings, loadDoctors])

  async function bookChat(plan) {
    setError('')
    const response = await fetch('http://localhost:5001/api/chat/bookings', {
      method: 'POST',
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ doctorId: selectedDoctor, plan }),
    })
    const data = await response.json()
    if (!response.ok) {
      setError(data.error || 'Unable to book chat.')
      return
    }
    loadBookings()
  }

  async function openChat(booking) {
    setSelectedBooking(booking)
    const response = await fetch(`http://localhost:5001/api/chat/bookings/${booking.id}/messages`, { headers })
    if (response.ok) setMessages(await response.json())
    loadBookings()
  }

  async function sendMessage(event) {
    event.preventDefault()
    if ((!message.trim() && !attachment) || !selectedBooking) return
    const response = await fetch(`http://localhost:5001/api/chat/bookings/${selectedBooking.id}/messages`, {
      method: 'POST',
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, attachment }),
    })
    if (response.ok) {
      setMessage('')
      setAttachment(null)
      openChat(selectedBooking)
    }
  }

  async function updateStatus(status) {
    await fetch(`http://localhost:5001/api/chat/bookings/${selectedBooking.id}/status`, {
      method: 'PATCH',
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ status }),
    })
    loadBookings()
    setSelectedBooking({ ...selectedBooking, status })
  }

  async function toggleAvailability() {
    const response = await fetch('http://localhost:5001/api/doctors/me/availability', {
      method: 'PATCH',
      headers: { ...headers, 'Content-Type': 'application/json' },
      body: JSON.stringify({ available: !available }),
    })
    if (response.ok) setAvailable(!available)
  }

  if (!token) return <div className="page"><h1>Please login to use doctor chat.</h1></div>

  return (
    <div className="page">
      <h1>Doctor chat</h1>
      {user?.role === 'doctor' && (
        <button className="btn availability-button" onClick={toggleAvailability}>
          {available ? 'Available for new chats' : 'Currently unavailable'}
        </button>
      )}
      {user?.role === 'patient' && (
        <div className="form">
          <label htmlFor="doctor">Choose an approved doctor</label>
          <select id="doctor" value={selectedDoctor} onChange={(event) => setSelectedDoctor(event.target.value)}>
            <option value="">
              {loadingDoctors ? 'Loading doctors...' : doctors.length ? 'Select doctor' : 'No approved doctors available'}
            </option>
            {doctors.map((doctor) => (
              <option key={doctor.id} value={doctor.id}>
                {doctor.name} · {doctor.specialty || 'General Physician'} · {doctor.available ? 'Available' : 'Unavailable'}
              </option>
            ))}
          </select>
          {doctors.length === 0 && !loadingDoctors && (
            <p className="error-message">No approved doctors are available yet. Ask an admin to approve a doctor.</p>
          )}
          <div className="plan-buttons">
            <button className="btn" disabled={!selectedDoctor} onClick={() => bookChat(200)}>Book chat - ₹200</button>
            <button className="btn" disabled={!selectedDoctor} onClick={() => bookChat(500)}>Book priority chat - ₹500</button>
          </div>
          {error && <p className="error-message">{error}</p>}
        </div>
      )}
      <div className="chat-layout">
        <div className="chat-bookings">
          <h3>Your chat bookings</h3>
          {bookings.length === 0 && <p>No chat bookings yet.</p>}
          {bookings.map((booking) => (
            <button className={`chat-booking ${selectedBooking?.id === booking.id ? 'selected-booking' : ''}`} key={booking.id} onClick={() => openChat(booking)}>
              <strong>₹{booking.plan}</strong> · {user?.role === 'doctor' ? booking.patient : booking.doctor}
              <small>{booking.status} {booking.unread_count > 0 && `· ${booking.unread_count} unread`}</small>
            </button>
          ))}
        </div>
        {selectedBooking && (
          <div className="chat-panel">
            <div className="chat-panel-heading">
              <div><h3>Chat · ₹{selectedBooking.plan}</h3><span>{selectedBooking.status}</span></div>
              <div className="chat-status-actions">
                {selectedBooking.status === 'booked' && <button className="text-button" onClick={() => updateStatus('active')}>Start</button>}
                {selectedBooking.status === 'active' && <button className="text-button" onClick={() => updateStatus('completed')}>Complete</button>}
                {!['completed', 'cancelled'].includes(selectedBooking.status) && <button className="text-button danger-text" onClick={() => updateStatus('cancelled')}>Cancel</button>}
              </div>
            </div>
            <div className="messages">
              {messages.length === 0 && <p>No messages yet. Start the conversation.</p>}
              {messages.map((item) => (
                <div key={item.id} className={`message-row ${item.sender_id === user.id ? 'mine' : ''}`}>
                  <p>
                    {item.message}
                    {item.attachment_data && <a className="chat-attachment" href={item.attachment_data} download={item.attachment_name}>{item.attachment_name || 'Download attachment'}</a>}
                    <small>{new Date(item.created_at).toLocaleString()}</small>
                  </p>
                </div>
              ))}
            </div>
            {!['completed', 'cancelled'].includes(selectedBooking.status) && (
              <form onSubmit={sendMessage} className="chat-input">
                <input value={message} onChange={(event) => setMessage(event.target.value)} placeholder="Write a message" />
                <label className="attachment-button" htmlFor="chat-attachment">Attach</label>
                <input
                  id="chat-attachment"
                  className="hidden-input"
                  type="file"
                  accept="image/*,.pdf,.txt"
                  onChange={(event) => {
                    const file = event.target.files?.[0]
                    if (!file) return
                    const reader = new FileReader()
                    reader.onload = () => setAttachment({ name: file.name, data: reader.result })
                    reader.readAsDataURL(file)
                  }}
                />
                <button className="btn">Send</button>
              </form>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
