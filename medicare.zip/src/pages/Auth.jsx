import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

export default function Auth() {
  const navigate = useNavigate()
  const [mode, setMode] = useState('login')
  const [role, setRole] = useState('patient')
  const [form, setForm] = useState({ name: '', email: '', password: '' })
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  function updateField(event) {
    setForm({ ...form, [event.target.name]: event.target.value })
  }

  async function submit(event) {
    event.preventDefault()
    setMessage('')
    setError('')
    const endpoint = mode === 'login' ? 'login' : 'register'
    const body = mode === 'login' ? form : { ...form, role }
    const response = await fetch(`http://localhost:5001/api/auth/${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    const data = await response.json()
    if (!response.ok) {
      setError(data.error || 'Request failed.')
      return
    }
    if (mode === 'register') {
      setMessage(data.message)
      setMode('login')
      return
    }
    localStorage.setItem('medicare_token', data.token)
    localStorage.setItem('medicare_user', JSON.stringify(data.user))
    window.dispatchEvent(new Event('medicare-auth-changed'))
    navigate(
      data.user.role === 'admin'
        ? '/admin'
        : data.user.role === 'doctor'
          ? '/doctor-dashboard'
          : '/appointment'
    )
  }

  return (
    <div className="page">
      <h1>{mode === 'login' ? 'Login' : 'Create an account'}</h1>
      <form className="form" onSubmit={submit}>
        {mode === 'register' && (
          <>
            <label htmlFor="name">Name</label>
            <input id="name" name="name" value={form.name} onChange={updateField} required />
            <label htmlFor="role">Account type</label>
            <select id="role" value={role} onChange={(event) => setRole(event.target.value)}>
              <option value="patient">Patient</option>
              <option value="doctor">Doctor</option>
            </select>
          </>
        )}
        <label htmlFor="email">Email</label>
        <input id="email" name="email" type="email" value={form.email} onChange={updateField} required />
        <label htmlFor="password">Password</label>
        <input id="password" name="password" type="password" minLength="6" value={form.password} onChange={updateField} required />
        <button className="btn" type="submit">
          {mode === 'login' ? 'Login' : 'Register'}
        </button>
        {message && <p className="success-message">{message}</p>}
        {error && <p className="error-message">{error}</p>}
      </form>
      <button className="text-button" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
        {mode === 'login' ? 'Create a new account' : 'Already have an account? Login'}
      </button>
    </div>
  )
}
