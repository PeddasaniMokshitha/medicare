import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export default function DoctorDashboard() {
  const token = localStorage.getItem('medicare_token')
  const [bookings, setBookings] = useState([])

  useEffect(() => {
    let active = true
    fetch('http://localhost:5001/api/chat/bookings', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((response) => response.ok ? response.json() : [])
      .then((data) => {
        if (active) setBookings(data)
      })
      .catch((error) => console.error(error))

    return () => { active = false }
  }, [token])

  return (
    <div className="page">
      <h1>Doctor workspace</h1>
      <p>Review your paid chat bookings and respond to patients.</p>
      {bookings.length === 0 ? (
        <p>No chat bookings yet.</p>
      ) : (
        <div className="table-wrapper">
          <table className="appointments-table">
            <thead>
              <tr><th>Booking</th><th>Patient</th><th>Plan</th><th>Status</th><th>Action</th></tr>
            </thead>
            <tbody>
              {bookings.map((booking) => (
                <tr key={booking.id}>
                  <td>#{booking.id}</td>
                  <td>{booking.patient}</td>
                  <td>₹{booking.plan}</td>
                  <td>{booking.status}</td>
                  <td><Link className="btn" to="/chat">Open chat</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
