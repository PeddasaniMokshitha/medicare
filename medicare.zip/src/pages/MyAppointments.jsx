import { useState, useEffect } from 'react'

export default function MyAppointments() {
  const [appointments, setAppointments] = useState([])

  useEffect(() => {
    let active = true

    fetch('http://localhost:5001/api/appointments')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Unable to load appointments')
        }
        return response.json()
      })
      .then((data) => {
        if (active) {
          setAppointments(data)
        }
      })
      .catch((error) => {
        console.error(error)
      })

    return () => {
      active = false
    }
  }, [])

  async function cancelAppointment(id) {
    const response = await fetch(`http://localhost:5001/api/appointments/${id}`, {
      method: 'DELETE',
    })
    if (!response.ok) {
      throw new Error('Unable to cancel appointment')
    }

    setAppointments((current) =>
      current.filter((appointment) => appointment.id !== id)
    )
  }

  return (
    <div className="page">
      <h1>My Appointments</h1>

      {appointments.length === 0 ? (
        <p>No appointments booked yet.</p>
      ) : (
        <div className="table-wrapper">
          <table className="appointments-table">
            <thead>
              <tr>
                <th scope="col">ID</th>
                <th scope="col">Patient</th>
                <th scope="col">Doctor</th>
                <th scope="col">Date</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((appointment) => (
                <tr key={appointment.id}>
                  <td>{appointment.id}</td>
                  <td>{appointment.name}</td>
                  <td>{appointment.doctor}</td>
                  <td>{appointment.date}</td>
                  <td>
                    <button
                      className="btn cancel-btn"
                      onClick={() => cancelAppointment(appointment.id)}
                    >
                      Cancel
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}