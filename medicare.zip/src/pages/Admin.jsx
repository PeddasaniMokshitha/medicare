import { useEffect, useState } from 'react'

export default function Admin() {
  const [doctors, setDoctors] = useState([])
  const token = localStorage.getItem('medicare_token')

  async function loadDoctors() {
    const response = await fetch('http://localhost:5001/api/admin/doctors', {
      headers: { Authorization: `Bearer ${token}` },
    })
    if (response.ok) setDoctors(await response.json())
  }

  useEffect(() => {
    let active = true
    fetch('http://localhost:5001/api/admin/doctors', {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((response) => response.ok ? response.json() : [])
      .then((data) => {
        if (active) setDoctors(data)
      })
      .catch((error) => console.error(error))
    return () => { active = false }
  }, [token])

  async function updateDoctor(id, status) {
    await fetch(`http://localhost:5001/api/admin/doctors/${id}`, {
      method: 'PATCH',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ status }),
    })
    loadDoctors()
  }

  return (
    <div className="page">
      <h1>Doctor approvals</h1>
      <div className="table-wrapper">
        <table className="appointments-table">
          <thead>
            <tr><th>Name</th><th>Email</th><th>Status</th><th>Action</th></tr>
          </thead>
          <tbody>
            {doctors.map((doctor) => (
              <tr key={doctor.id}>
                <td>{doctor.name}</td>
                <td>{doctor.email}</td>
                <td>{doctor.status}</td>
                <td>
                  <button className="btn" onClick={() => updateDoctor(doctor.id, 'approved')}>Approve</button>{' '}
                  <button className="btn cancel-btn" onClick={() => updateDoctor(doctor.id, 'rejected')}>Reject</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
