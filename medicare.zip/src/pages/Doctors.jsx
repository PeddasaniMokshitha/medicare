import { useEffect, useState } from 'react'

export default function Doctors() {
  const [doctors, setDoctors] = useState([])
  const [selectedDoctor, setSelectedDoctor] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    let active = true
    fetch('http://localhost:5001/api/doctors')
      .then((response) => {
        if (!response.ok) throw new Error('Unable to load doctors')
        return response.json()
      })
      .then((data) => {
        if (active) setDoctors(data)
      })
      .catch(() => {
        if (active) setError('Unable to load doctor profiles. Please try again.')
      })
      .finally(() => {
        if (active) setLoading(false)
      })

    return () => { active = false }
  }, [])

  return (
    <div className="page">
      <h1>Our Doctors</h1>
      <p>Click a doctor to view qualifications, experience, availability, and consultation fees.</p>
      {loading && <p>Loading doctors...</p>}
      {error && <p className="error-message">{error}</p>}
      {!loading && !error && doctors.length === 0 && <p>No approved doctors are available yet.</p>}

      <div className="grid">
        {doctors.map((doctor) => (
          <button className="doctor-card" key={doctor.id} onClick={() => setSelectedDoctor(doctor)}>
            <span className="doctor-avatar">{doctor.name.replace('Dr. ', '').slice(0, 1)}</span>
            <h3>{doctor.name}</h3>
            <p>{doctor.specialty || 'General Physician'}</p>
            <span className={`availability-label ${doctor.available ? '' : 'unavailable'}`}>
              {doctor.available ? 'Available' : 'Unavailable'}
            </span>
            <span className="doctor-card-link">View complete profile →</span>
          </button>
        ))}
      </div>

      {selectedDoctor && (
        <div className="doctor-modal-backdrop" role="presentation" onClick={() => setSelectedDoctor(null)}>
          <section className="doctor-modal" role="dialog" aria-modal="true" aria-labelledby="doctor-profile-title" onClick={(event) => event.stopPropagation()}>
            <button className="modal-close" onClick={() => setSelectedDoctor(null)} aria-label="Close doctor profile">×</button>
            <span className="doctor-avatar">{selectedDoctor.name.replace('Dr. ', '').slice(0, 1)}</span>
            <h2 id="doctor-profile-title">{selectedDoctor.name}</h2>
            <p className="doctor-specialty">{selectedDoctor.specialty || 'General Physician'}</p>
            <p>{selectedDoctor.bio}</p>
            <div className="doctor-details">
              <p><strong>Qualification</strong>{selectedDoctor.qualification}</p>
              <p><strong>Experience</strong>{selectedDoctor.experience_years} years</p>
              <p><strong>Status</strong>{selectedDoctor.available ? 'Available for chat' : 'Currently unavailable'}</p>
              <p><strong>Consultation / chat fee</strong>₹{selectedDoctor.consultation_fee}</p>
            </div>
          </section>
        </div>
      )}
    </div>
  )
}
