import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar.jsx'
import Home from './pages/Home.jsx'
import Doctors from './pages/Doctors.jsx'
import Appointment from './pages/Appointment.jsx'
import MyAppointments from './pages/MyAppointments.jsx'
import Chatbot from './components/chatbot.jsx'
import Auth from './pages/Auth.jsx'
import Admin from './pages/Admin.jsx'
import DoctorChat from './pages/DoctorChat.jsx'
import ProtectedRoute from './components/ProtectedRoute.jsx'
import DoctorDashboard from './pages/DoctorDashboard.jsx'

function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/doctors" element={<Doctors />} />
        <Route path="/appointment" element={<ProtectedRoute roles={['patient']}><Appointment /></ProtectedRoute>} />
        <Route path="/my-appointments" element={<ProtectedRoute roles={['patient']}><MyAppointments /></ProtectedRoute>} />
        <Route path="/auth" element={<Auth />} />
        <Route path="/admin" element={<ProtectedRoute roles={['admin']}><Admin /></ProtectedRoute>} />
        <Route path="/doctor-dashboard" element={<ProtectedRoute roles={['doctor']}><DoctorDashboard /></ProtectedRoute>} />
        <Route path="/chat" element={<ProtectedRoute roles={['patient', 'doctor']}><DoctorChat /></ProtectedRoute>} />
      </Routes>
      <Chatbot />
    </>
  )
}

export default App